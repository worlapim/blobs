function is_clicked()
{

}
function is_right_clicked()
{

}

function draw(_x,_y)
{
	draw_sprite(sprite_index,0,_x,_y)
}
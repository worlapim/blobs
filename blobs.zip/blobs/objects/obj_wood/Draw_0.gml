
draw_self();

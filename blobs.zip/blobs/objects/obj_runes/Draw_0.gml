//gpu_set_blendmode(bm_max)
draw_sprite_ext(spr_runes,0,x ,y , image_xscale, image_yscale, 0,c_fuchsia,image_alpha);
//gpu_set_blendmode(bm_normal)
draw_head_cycle += (1/TICS_PER_SECOND)*10;
if (draw_head_cycle > 5)
{
	draw_head_cycle = -5
}
draw(x,y);
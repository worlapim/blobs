
if (global.clock.is_night_fuzzy < 1)
{
	split_tonight = false;
	var _did_this = follow_waypoints_if_want_and_can();

	if (x_to == x && y == y_to)
	{
		if (not _did_this)
		{
			_did_this = eat_food_if_want_and_can();
		}
		if (not _did_this and demand_selected == DEMANDS.CONSTRUCT)
		{
			_did_this = construct_if_want_and_can();
		}
		if (not _did_this)
		{
			_did_this = pray_if_want_and_can();
		}
		if (not _did_this and (saturation_seconds <= max_saturation_seconds or demand_selected == DEMANDS.NONE))
		{
			_did_this = eat_food_if_want_and_can();
		}
		if (not _did_this)
		{
			_did_this = place_sappling_if_want_and_can();
		}
		if (not _did_this)
		{
			move_in_random_direction();
		}
	}

	saturation_seconds -= (sqr(vision_range_tile/4) + sqr(move_speed/4))/TICS_PER_SECOND/2;
	if (saturation_seconds < 0)
	{
		instance_destroy(self)
	}


	motivation_cooldown_seconds_now -= 1/TICS_PER_SECOND;
	if(get_tree_in_tiny_radius(x,y,move_speed) != noone and motivation_cooldown_seconds_now <= 0)
	{
		add_demand(DEMANDS.CHOP_DOWN)
		motivation_cooldown_seconds_now = motivation_cooldown_seconds
	}
	if(get_wood_in_tiny_radius(x,y,move_speed) != noone and motivation_cooldown_seconds_now <= 0)
	{
		add_demand(DEMANDS.CONSTRUCT)
		motivation_cooldown_seconds_now = motivation_cooldown_seconds
	}
	if(get_flowers_in_tiny_radius(x,y,move_speed) != noone and motivation_cooldown_seconds_now <= 0)
	{
		add_demand(DEMANDS.POLLINATE)
		motivation_cooldown_seconds_now = motivation_cooldown_seconds
	}

	x += min(abs(x - x_to), move_speed) * (x_to > x ? 1 : -1);
	y += min(abs(y - y_to), move_speed) * (y_to > y ? 1 : -1);

}
//else
//{
//	if (saturation_seconds > 20 and split_tonight == false)
//	{
//		split_self()
//		split_tonight = true;
//	}
//}

if (!keep_standing)
{
	standing_time = 0;
}
keep_standing = false;

update_shadow(self);
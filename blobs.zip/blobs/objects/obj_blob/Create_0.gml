event_inherited();
demand_slot_count = 4;
motivation_cooldown_seconds_now = 0;
x_to = x;
y_to = y;
demand_slots = array_create(demand_slot_count, DEMANDS.NONE);
demand_selected = DEMANDS.NONE;
draw_head_cycle = random_range(-5,5);
split_tonight = false;
holding_item = ITEMS.NONE;
standing_time = 0;
keep_standing = false;


#macro EAT_TIME_STANDING_SECOND 0.5
#macro PRAY_TIME_STANDING_SECOND 1.5
#macro CONSTRUCT_TIME_STANDING_SECOND 5
#macro TINY_RADIUS move_speed * 1.5

function is_right_clicked()
{
	
}
function is_clicked()
{
	if (global.clock.is_night_fuzzy == 1)
	{
		split_self()
	}
}


function split_self(_child_count)
{
	plop_sound();
    _child_count = is_undefined(_child_count) ? 2 : _child_count;
	var _spawn_x = round(x/TILE_WIDTH)*TILE_WIDTH;
	var _spawn_y = round(y/TILE_WIDTH)*TILE_WIDTH;
	var _child = birth_child(_spawn_x,_spawn_y,saturation_seconds/_child_count);
	_child.holding_item = holding_item;
	for (var _i = 0; _i < _child_count-1; _i++)
	{
		var _spot = random_neigboring_slot(_spawn_x,_spawn_y);
		birth_child(_spot.x,_spot.y,saturation_seconds/_child_count);
	}
	instance_destroy(self);
}

function birth_child(_x,_y,_saturation_seconds)
{
	var _child = instance_create_layer(_x,_y,"Blobs",obj_blob);
	array_copy(_child.demand_slots, 0, demand_slots, 0, demand_slot_count-1);
	_child.saturation_seconds = _saturation_seconds;
	_child.asign_own_demand();
	_child.vision_range_tile = random_around(vision_range_tile, 1, true);
	_child.move_speed = random_around(move_speed, 1, true);
	_child.motivation_cooldown_seconds = random_around(motivation_cooldown_seconds, 1, true);
	_child.split_tonight = true;
	return _child;
}

function add_demand(_demand)
{
	var _chosen_slot = irandom(demand_slot_count-1);
	demand_slots[_chosen_slot] = _demand;
}

function get_random_demand()
{
	var _chosen_slot = irandom(demand_slot_count-1);
	return demand_slots[_chosen_slot];
}

function asign_own_demand()
{
	demand_selected =  get_random_demand();
}

function eat_food_if_want_and_can()
{
	var _food = spot_nearest_something(get_food_in_tiny_radius);
	if (_food != noone and (saturation_seconds <= max_saturation_seconds or demand_selected == DEMANDS.NONE or (demand_selected == DEMANDS.CHOP_DOWN and _food.bush_stage == BUSH_STAGES.TREE)))
	{
		x_to = _food.x;
		y_to = _food.y;
		
		if (_food.x == x and _food.y == y)
		{
			if (standing_time < EAT_TIME_STANDING_SECOND * TICS_PER_SECOND)
			{
				standing_time += 1;
				keep_standing = true;
			}
			else
			{
				if (demand_selected != DEMANDS.POLLINATE and _food.get_sapling_while_eating())
				{
					holding_item = ITEMS.SAPLING;
				}
				saturation_seconds += _food.eat_all(demand_selected == DEMANDS.POLLINATE)
				if (_food.bush_stage == BUSH_STAGES.TREE && demand_selected == DEMANDS.CHOP_DOWN)
				{
					_food.chop_down()
				}
			}
		}
	}
	return _food != noone;
}

function pray_if_want_and_can()
{
	var _spot = spot_nearest_something(get_pray_spot_in_tiny_radius);
	if (_spot != noone)
	{
		x_to = _spot.x;
		y_to = _spot.y;
		if (_spot.x == x && _spot.y == y)
		{
			if (standing_time < PRAY_TIME_STANDING_SECOND * TICS_PER_SECOND)
			{
				standing_time += 1;
				keep_standing = true;
			}
			else
			{
				_spot.collect_all()
			}
		}
	}
	return _spot != noone;
}

function construct_if_want_and_can()
{
	var _spot = spot_nearest_something(get_wood_in_tiny_radius);
	if (_spot != noone)
	{
		x_to = _spot.x;
		y_to = _spot.y;
		if (_spot.x == x && _spot.y == y)
		{
			if (standing_time < CONSTRUCT_TIME_STANDING_SECOND * TICS_PER_SECOND)
			{
				standing_time += 1;
				keep_standing = true;
			}
			else
			{
				build_something(_spot);
			}
		}
	}
	return _spot != noone;
}

function follow_waypoints_if_want_and_can()
{
	var _spot = spot_nearest_something(get_waypoint_in_tiny_radius);
	if (_spot != noone)
	{
		if (_spot.x == x && _spot.y == y)
		{
			switch(_spot.direction_pointed)
			{
				case DIRECTIONS.NORTH:
					x_to = x;
					y_to = y - _spot.distance*TILE_WIDTH;
					break;
				case DIRECTIONS.SOUTH:
					x_to = x;
					y_to = y + _spot.distance*TILE_WIDTH;
					break;
				case DIRECTIONS.EAST:
					x_to = x + _spot.distance*TILE_WIDTH;
					y_to = y;
					break;
				case DIRECTIONS.WEST:
					x_to = x - _spot.distance*TILE_WIDTH;
					y_to = y;
					break;
				default:
					return false;
			}
		}
		else
		{
			x_to = _spot.x;
			y_to = _spot.y;
		}
	}
	return _spot != noone;
}

function place_sappling_if_want_and_can()
{
	if(holding_item == ITEMS.SAPLING and noone = get_static_object_in_tiny_radius(x,y,TINY_RADIUS))
	{
		holding_item = ITEMS.NONE;
		var _sapling = instance_create_layer(x,y,"Landmarks",obj_bush);
		_sapling.bush_stage = BUSH_STAGES.SAPPLING;
		_sapling.clear_all_fruit();
	}
}

function is_waypoint_in_a_way(_x_destination, _y_destination)
{
	var _margin_of_offset = TINY_RADIUS;
	var _x = x;
	var _y = y;
	while(_x != _x_destination or _y != _y_destination)
	{
		if(_x < _x_destination)
		{
			_x++;
		}
		else if(_x > _x_destination)
		{
			_x--;
		}
		if(_y < _y_destination)
		{
			_y++;
		}
		else if(_y > _y_destination)
		{
			_y--;
		}
		var _found = get_waypoint_in_tiny_radius(_x,_y,_margin_of_offset,true);
		if(_found != noone)
		{
			return true;
		}
	}
	return false;
}
function is_water_in_a_way(_x_destination, _y_destination)
{
	var _margin_of_offset = TINY_RADIUS;
	var _x = x;
	var _y = y;
	while(_x != _x_destination or _y != _y_destination)
	{
		if(_x < _x_destination)
		{
			_x++;
		}
		else if(_x > _x_destination)
		{
			_x--;
		}
		if(_y < _y_destination)
		{
			_y++;
		}
		else if(_y > _y_destination)
		{
			_y--;
		}
		var _found = get_water_in_tiny_radius(_x,_y);
		show_debug_message("is_water_in_a_way");
		show_debug_message(_found);
		if(_found)
		{
			return true;
		}
	}
	return false;
}

function build_something(_material)
{
	if(_material.object_index == obj_wood)
	{
		var _building;
		switch(irandom(1))
		{
			case 0:
			_building = instance_create_layer(x,y,"Landmarks",obj_flowers);
			break;
			case 1:
			_building = instance_create_layer(x,y,"Landmarks",obj_waypoint);
			break;
		}
		instance_destroy(_material);
	}
}

function move_in_random_direction()
{
	var _spot = random_neigboring_slot(x,y);
	if(not is_something_in_a_way(_spot.x, _spot.y))
	{
		x_to = _spot.x;
		y_to = _spot.y;
	}
}

function spot_nearest_something(_search_function,_check_waypoint,_check_something_in_a_way)
{
	 _check_waypoint = is_undefined(_check_waypoint) ? true : _check_waypoint;
	 _check_something_in_a_way = is_undefined(_check_something_in_a_way) ? true : _check_something_in_a_way;
	var _dir_list = ds_list_create()
	ds_list_add(_dir_list,0,1,2,3)
	ds_list_shuffle(_dir_list)
	var _margin_of_offset = TINY_RADIUS;
	for (var _distance = 0; _distance <= vision_range_tile * TILE_WIDTH; _distance += TILE_WIDTH)
	{
		for (var _dir_i = 0; _dir_i <= 3; _dir_i++){
			var _found = noone;
			switch (ds_list_find_value(_dir_list, _dir_i))
			{
			    case 0:
					_found = _search_function(x + _distance, y, _margin_of_offset);
					break;
			    case 1:
					_found = _search_function(x , y + _distance, _margin_of_offset);
					break;
			    case 2:
					_found = _search_function(x - _distance, y, _margin_of_offset);
					break;
			    case 3:
					_found = _search_function(x, y - _distance, _margin_of_offset);
					break;
			    default:
					break;
			}
			if(_found != noone)
			{
				show_debug_message("something");
				show_debug_message(_found != noone);
				show_debug_message("waypoint");
				show_debug_message(((not is_waypoint_in_a_way(_found.x, _found.y))));
				show_debug_message(( not _check_waypoint));
				show_debug_message("water");
				show_debug_message(((not is_something_in_a_way(_found.x, _found.y))));
				show_debug_message((not _check_something_in_a_way));
			}
			if (_found != noone and ((not is_waypoint_in_a_way(_found.x, _found.y)) or not _check_waypoint) and ((not is_something_in_a_way(_found.x, _found.y)) or not _check_something_in_a_way))
			{
				return _found;
			}
			
		}
	}
	return noone;
}

function is_something_in_a_way(_x,_y)
{
	 return is_water_in_a_way(_x, _y);
}



function get_food_in_tiny_radius(_x,_y,_radius)
{
	var _obj = instance_nearest(_x,_y,obj_bush)
	if(_obj != noone and abs(_x - _obj.x) < _radius && abs(_y - _obj.y) < _radius && _obj.has_fruit(demand_selected != DEMANDS.POLLINATE) and (_obj.bush_stage == BUSH_STAGES.BUSH or (_obj.bush_stage == BUSH_STAGES.TREE and demand_selected == DEMANDS.CHOP_DOWN)))
	{
		return _obj;
	}
	return noone;
}

function get_tree_in_tiny_radius(_x,_y,_radius)
{
	var _obj = instance_nearest(_x,_y,obj_bush)
	if(_obj != noone and abs(_x - _obj.x) < _radius && abs(_y - _obj.y) < _radius && _obj.bush_stage == BUSH_STAGES.TREE)
	{
		return _obj;
	}
	return noone;
}

function get_pray_spot_in_tiny_radius(_x,_y,_radius)
{
	var _obj = instance_nearest(_x,_y,obj_stone)
	if(_obj != noone and abs(_x - _obj.x) < _radius && abs(_y - _obj.y) < _radius && _obj.has_energy())
	{
		return _obj;
	}
	return noone;
}


function get_flowers_in_tiny_radius(_x,_y,_radius)
{
	var _obj = instance_nearest(_x,_y,obj_flowers)
	if(_obj != noone and abs(_x - _obj.x) < _radius and abs(_y - _obj.y) < _radius)
	{
		return _obj;
	}
	return noone;
}

function get_wood_in_tiny_radius(_x,_y,_radius)
{
	var _obj = instance_nearest(_x,_y,obj_wood)
	if(_obj != noone and abs(_x - _obj.x) < _radius and abs(_y - _obj.y) < _radius)
	{
		return _obj;
	}
	return noone;
}

function get_static_object_in_tiny_radius(_x,_y,_radius)
{
	var _obj = instance_nearest_multiple_objects(_x,_y,STATIC_OBJECTS);
	if(_obj != noone and abs(_x - _obj.x) < _radius and abs(_y - _obj.y) < _radius)
	{
		return _obj;
	}
	return noone;
}

function get_waypoint_in_tiny_radius(_x,_y,_radius,_pointing_at_me)
{
    _pointing_at_me = is_undefined(_pointing_at_me) ? false : _pointing_at_me;
	var _obj = instance_nearest(_x,_y,obj_waypoint)
	if(_obj != noone and abs(_x - _obj.x) < _radius and abs(_y - _obj.y) < _radius and 
		(_obj.demand == DEMANDS.NONE or _obj.demand == self.demand_selected) and
		(not _pointing_at_me and(   
			(_obj.direction_pointed == DIRECTIONS.NORTH and not (_obj.y > y)) or
			(_obj.direction_pointed == DIRECTIONS.SOUTH and not (_obj.y < y)) or
			(_obj.direction_pointed == DIRECTIONS.EAST and not (_obj.x < x)) or
			(_obj.direction_pointed == DIRECTIONS.WEST and not (_obj.x > x)))
		or _pointing_at_me and(
			(_obj.direction_pointed == DIRECTIONS.NORTH and (_obj.y > y)) or
			(_obj.direction_pointed == DIRECTIONS.SOUTH and (_obj.y < y)) or
			(_obj.direction_pointed == DIRECTIONS.EAST and (_obj.x < x)) or
			(_obj.direction_pointed == DIRECTIONS.WEST and (_obj.x > x)))))
	{
		return _obj;
	}
	return noone;
}

function get_water_in_tiny_radius(_x,_y)
{
	var _layer_id = layer_get_id("water");
	var _map_id = layer_tilemap_get_id(_layer_id);
	show_debug_message( "bbb");
	show_debug_message( _layer_id);
	show_debug_message( _map_id);
	show_debug_message( tilemap_get_at_pixel(_map_id, _x, _y));
	return tilemap_get_at_pixel(_map_id, _x, _y);
}

function draw(_x,_y)
{
	var _draw_scale = 1/2 + saturation_seconds/max_saturation_seconds/2;
	var _offset_by_scale_x = (1 - _draw_scale) * TILE_WIDTH / 2;
	var _offset_by_scale_y = (1 - _draw_scale) * TILE_WIDTH;
	self.image_xscale = _draw_scale;
	self.image_yscale = _draw_scale;


	draw_sprite_ext(spr_blob_body, 0, _x + _offset_by_scale_x, _y + _offset_by_scale_y, self.image_xscale, self.image_yscale, 0, c_fuchsia, 1)
	draw_sprite_ext(spr_blob_head, 0, _x + abs(draw_head_cycle)*_draw_scale + _offset_by_scale_x, _y + _offset_by_scale_y, self.image_xscale, self.image_yscale, 0, c_fuchsia, 1)



	var _vision_sprite = noone;
	if (vision_range_tile <= 1)
	{
		_vision_sprite = spr_blob_blindfold;
	}

	if (vision_range_tile >= 8)
	{
		_vision_sprite = spr_blob_glasses;
	}


	if (_vision_sprite != noone)
	{
		draw_sprite_ext(_vision_sprite, 0, _x + abs(draw_head_cycle)*_draw_scale + _offset_by_scale_x, _y + _offset_by_scale_y, self.image_xscale, self.image_yscale, 0, c_white, 1)
	}


	var _hat_sprite = get_hat(demand_selected);

	if (_hat_sprite != noone)
	{
		draw_sprite_ext(_hat_sprite, 0, _x + abs(draw_head_cycle)*_draw_scale + _offset_by_scale_x, _y + _offset_by_scale_y, self.image_xscale, self.image_yscale, 0, c_white, 1)
	}



	var _item_sprite = noone;
	switch (holding_item) 
	{
		case ITEMS.SAPLING:
			_item_sprite = spr_blob_sapling;
			break;
	}

	if (_item_sprite != noone)
	{
		draw_sprite_ext(_item_sprite, 0, _x + -abs(draw_head_cycle)*_draw_scale + _offset_by_scale_x, _y + _offset_by_scale_y, self.image_xscale, self.image_yscale, 0, c_white, 1)
	}

}

add_shadow(self);

draw_self()

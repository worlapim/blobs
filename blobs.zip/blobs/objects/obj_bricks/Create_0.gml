
add_shadow(self);
if (not hidden)
{
	var _offset_by_scale_x = (1 - image_xscale) * TILE_WIDTH / 2
	var _offset_by_scale_y = (1 - image_xscale) * TILE_WIDTH

	draw_sprite_ext(spr_shadow,0,x + (((global.clock.sec_in_day_now + global.clock.sec_per_day*(1/4))%global.clock.sec_per_day) - global.clock.sec_per_day*(2/4))/2 + _offset_by_scale_x,y + _offset_by_scale_y,image_xscale,image_yscale,0,c_white,(1 - global.clock.is_night_fuzzy)/8);
}
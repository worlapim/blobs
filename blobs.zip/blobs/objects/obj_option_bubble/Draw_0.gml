draw_self()
option_instance.draw(x+8,y+8)
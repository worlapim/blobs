if (not instance_exists(option_instance))
{
	instance_destroy(self);
}

if (mouse_check_button_pressed(click_type) or mouse_check_button_pressed(mb_left)) 
	and instance_exists(option_instance)
{
	if (mouse_x >= x and mouse_x <= x + sprite_width and mouse_y >= y and mouse_y <= y + sprite_height)
	{
		if (click_type == mb_left)
		{
			option_instance.is_clicked()
		}
		else if (click_type == mb_right)
		{
			option_instance.is_right_clicked()
		}
	}
	instance_destroy(self);
}

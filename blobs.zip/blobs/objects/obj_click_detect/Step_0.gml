
if ((mouse_check_button_pressed(mb_left) or mouse_check_button_pressed(click_type)) and is_selecting)
{
	is_selecting = false;
}
else
{
	var _click_types = [mb_left, mb_right]

	for (var _click_i = 0; _click_i < array_length(_click_types);_click_i++){
		var _click_type = _click_types[_click_i]
		if (mouse_check_button_pressed(_click_type) and not is_selecting)
		{
			var _my_selected_instance = noone;
			var _list = ds_list_create();
			var _list_num = collision_circle_list(mouse_x, mouse_y, 1, obj_clickable, false, true, _list, true);
			show_debug_message(_list_num)
			if (_list_num == 1) {
				_my_selected_instance = _list[|0];
				if (_click_type == mb_left)
				{
					_my_selected_instance.is_clicked();
				}
				else if (_click_type == mb_right)
				{
					_my_selected_instance.is_right_clicked();
				}
			}
			else if (_list_num == 0) {
			}
			else
			{
				is_selecting = true;
				for (var _i = 0; _i < _list_num; _i++)
				{
					var _offset_x = sin((_i/_list_num) * (pi*2))*70 - 40;
					var _offset_y = cos((_i/_list_num) * (pi*2))*70 - 40;
					instance_create_layer(mouse_x+_offset_x,mouse_y+_offset_y,"Options",obj_option_bubble,{
					    option_instance : _list[| _i],
					    click_type : _click_type
					});
				}
			}
			ds_list_destroy(_list);
		}
	}
}


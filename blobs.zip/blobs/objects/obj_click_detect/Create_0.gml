is_selecting = false;
click_type = mb_left;
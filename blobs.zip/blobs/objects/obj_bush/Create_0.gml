event_inherited();
slot_count = 3;

position1 =
{
    x : 15,
    y : 32,
};
position2 =
{
    x : 37,
    y : 30,
};
position3 =
{
    x : 28,
    y : 45,
};

fruit_slot = array_create(slot_count, FRUITS.NONE);
slot_position = array_create(slot_count);

slot_position[0] = position1;
slot_position[1] = position2;
slot_position[2] = position3;


bush_stage = BUSH_STAGES.BUSH;

function has_fruit(_including_pollinated)
{
	_including_pollinated = is_undefined(_including_pollinated) ? true : _including_pollinated;
	for (var _i = 0; _i < slot_count; _i += 1)
	{
		if (fruit_slot[_i] != FRUITS.NONE and (_including_pollinated or (not _including_pollinated and fruit_slot[_i] != FRUITS.POLLINATION_FRUIT)))
		{
			return true;
		}
	}
	return false;
}

function eat_all(_pollinate)
{
	_pollinate = is_undefined(_pollinate) ? false : _pollinate;
	var _saturation = 0;
	for (var _i = 0; _i < slot_count; _i += 1)
	{
		if (_pollinate and fruit_slot[_i] == FRUITS.POLLINATION_FRUIT)
		{
			continue;
		}
		_saturation += fruit_to_saturation(fruit_slot[_i]);
		if (_pollinate and fruit_slot[_i] != FRUITS.NONE)
		{
			fruit_slot[_i] = FRUITS.POLLINATION_FRUIT;
		}
		else
		{
			fruit_slot[_i] = FRUITS.NONE;
		}
	}
	return _saturation;
}

function clear_all_fruit()
{
	for (var _i = 0; _i < slot_count; _i += 1)
	{
		fruit_slot[_i] = FRUITS.NONE;
	}
}

function get_sapling_while_eating()
{
	for (var _i = 0; _i < slot_count; _i += 1)
	{
		if (fruit_slot[_i] == FRUITS.POLLINATION_FRUIT)
		{
			return true;
		}
	}
	return false;
}

function is_clicked()
{
	grow_fruit()
}

function grow_fruit(_is_free)
{
	_is_free = is_undefined(_is_free) ? false : _is_free;
	if ((global.energy >= 1 or _is_free) and bush_stage != BUSH_STAGES.SAPPLING)
	{
		var _empty_slots = ds_list_create();
		for (var _i = 0; _i < slot_count; _i += 1)
		{
			if (fruit_slot[_i] == FRUITS.NONE)
			{
				ds_list_add(_empty_slots, _i);
			}
		}
		var _empty_slot_count = ds_list_size(_empty_slots);
		if (_empty_slot_count > 0)
		{
			var _chosen_i = random_range(0, _empty_slot_count);
			if (bush_stage == BUSH_STAGES.TREE)
			{
				fruit_slot[ds_list_find_value(_empty_slots, _chosen_i)] = FRUITS.TREE_BASIC_FRUIT;
			}
			else if (bush_stage == BUSH_STAGES.BUSH)
			{
				fruit_slot[ds_list_find_value(_empty_slots, _chosen_i)] = FRUITS.BASIC_FRUIT;
			}
			if (not _is_free)
			{
				global.energy -= 1;
				bush_sound()
			}
		}
	}
}

function chop_down()
{
	var _child = instance_create_layer(x,y,"Landmarks",obj_wood);
	instance_destroy(self)
}

function is_right_clicked()
{
	if (global.energy >= 20 and bush_stage == BUSH_STAGES.BUSH)
	{
		bush_sound()
		bush_stage = BUSH_STAGES.TREE;
		global.energy -= 20;
	}
	if (global.energy >= 20 and bush_stage == BUSH_STAGES.SAPPLING)
	{
		bush_sound()
		bush_stage = BUSH_STAGES.BUSH;
		global.energy -= 20;
	}
}

add_shadow(self);

var _starting_fruit = irandom(3)
for (var _i = 0; _i < _starting_fruit; _i ++)
{
	grow_fruit(true)
}

function draw(_x,_y)
{
	switch(bush_stage)
	{
		case BUSH_STAGES.TREE:
			self.sprite_index = spr_tree;
			break;
		case BUSH_STAGES.BUSH:
			self.sprite_index = spr_bush_1;
			break;
		case BUSH_STAGES.SAPPLING:
			self.sprite_index = spr_sappling;
			break;
	}

	draw_sprite(sprite_index,0,_x,_y)

	for (var _i = 0; _i < slot_count; _i += 1)
	{
		if (fruit_slot[_i] != FRUITS.NONE)
		{
			var _sprite = spr_fruit;
			switch (fruit_slot[_i])
			{
				case FRUITS.BASIC_FRUIT:
					_sprite = spr_fruit_1;
					break;
				case FRUITS.TREE_BASIC_FRUIT:
					_sprite = spr_fruit_2;
					break;
				case FRUITS.POLLINATION_FRUIT:
					_sprite = spr_fruit_3;
					break;
				default:
					_sprite = spr_fruit;
					break;
			}
		
			if (bush_stage == BUSH_STAGES.TREE)
			{
				draw_sprite_ext(_sprite, 0, _x + slot_position[_i].x , _y + slot_position[_i].y -22, 1, 1, 0, c_fuchsia, 1);
			}
			else
			{
				draw_sprite_ext(_sprite, 0, _x+slot_position[_i].x , _y + slot_position[_i].y , 1, 1, 0, c_fuchsia, 1);
			}
		}
	}
}
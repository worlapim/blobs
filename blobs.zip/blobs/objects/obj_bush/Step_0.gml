if (1 == irandom(TICS_PER_SECOND*global.clock.sec_per_day))
{
	grow_fruit(true);
}

update_shadow(self)
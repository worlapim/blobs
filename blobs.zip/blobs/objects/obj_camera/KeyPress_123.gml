var _size = ds_map_size(global.particle_generators);
var _key = ds_map_find_first(global.particle_generators);
for (var _i = 0; _i < _size; _i++;)
{
	if (global.particle_generators[?_key] != noone)
	{
		part_system_destroy(global.particle_generators[?_key]);
	}
    _key = ds_map_find_next(global.particle_generators, _key);
}




game_restart()
if (follow != noone)
{
	x_to = follow.x;
	y_to = follow.y;
}

zoom_to = min(16,max(1/16, zoom_to ))

x += (x_to - x)/move_delay;
y += (y_to - y)/move_delay;
zoom += (zoom_to - zoom)/zoom_delay;


camera_set_view_pos(view_camera[0], x - cam_width/2/zoom, y - cam_height/2/zoom);
camera_set_view_size(view_camera[0], cam_width/zoom, cam_height/zoom);
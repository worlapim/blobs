cam_width = 640;
cam_height = 360;
zoom = 1;
zoom_to = 1;
cam_manual_speed = 20;
move_delay = 5;
zoom_delay = 5;

follow = noone;
global.camera = self;
global.energy = 100;
global.particle_generators = ds_map_create();

x_to = x;
y_to = y;
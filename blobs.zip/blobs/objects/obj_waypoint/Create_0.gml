event_inherited();
#macro MAX_DISTANCE 4
#macro MAX_DIRECTION 4

function is_clicked()
{
	if (direction_pointed == DIRECTIONS.NONE)
	{
		demand += 1;
		if (demand >= DEMANDS.length)
		{
			demand = 0;
		}
	}
	else
	{
		distance += 1;
		if (distance > MAX_DISTANCE)
		{
			distance = 1;
		}
	}
}
function is_right_clicked()
{
	direction_pointed += 1;
	if (direction_pointed > MAX_DIRECTION)
	{
		direction_pointed = 0;
	}
}

function draw(_x,_y)
{
	switch (direction_pointed)
	{
		case DIRECTIONS.NORTH:
			switch (distance)
			{
				case 1:
					self.sprite_index = spr_waypoint_north_1;
					break;
				case 2:
					self.sprite_index = spr_waypoint_north_2;
					break;
				case 3:
					self.sprite_index = spr_waypoint_north_3;
					break;
				case 4:
					self.sprite_index = spr_waypoint_north_4;
					break;
				default:
					self.sprite_index = spr_waypoint_blank;
			}
			break;
		case DIRECTIONS.EAST:
			switch (distance)
			{
				case 1:
					self.sprite_index = spr_waypoint_east_1;
					break;
				case 2:
					self.sprite_index = spr_waypoint_east_2;
					break;
				case 3:
					self.sprite_index = spr_waypoint_east_3;
					break;
				case 4:
					self.sprite_index = spr_waypoint_east_4;
					break;
				default:
					self.sprite_index = spr_waypoint_blank;
			}
			break;
		case DIRECTIONS.SOUTH:
			switch (distance)
			{
				case 1:
					self.sprite_index = spr_waypoint_south_1;
					break;
				case 2:
					self.sprite_index = spr_waypoint_south_2;
					break;
				case 3:
					self.sprite_index = spr_waypoint_south_3;
					break;
				case 4:
					self.sprite_index = spr_waypoint_south_4;
					break;
				default:
					self.sprite_index = spr_waypoint_blank;
			}
			break;
		case DIRECTIONS.WEST:
			switch (distance)
			{
				case 1:
					self.sprite_index = spr_waypoint_west_1;
					break;
				case 2:
					self.sprite_index = spr_waypoint_west_2;
					break;
				case 3:
					self.sprite_index = spr_waypoint_west_3;
					break;
				case 4:
					self.sprite_index = spr_waypoint_west_4;
					break;
				default:
					self.sprite_index = spr_waypoint_blank;
			}
			break;
		default:
			self.sprite_index = spr_waypoint_blank;
	}
	draw_sprite(sprite_index,0,_x,_y);

	var _hat_sprite = get_hat(demand);

	if (_hat_sprite != noone)
	{
		draw_sprite_ext(_hat_sprite, 0, _x, _y +50, self.image_xscale, self.image_yscale, 0, c_white, 1)
	}
}


add_shadow(self);
if (energy > 0 && energy < STONE_ENERGY_MAX)
{
	energy += STONE_ENERGY_PER_SECOND/TICS_PER_SECOND;
}


if (energy >= STONE_ENERGY_MAX and not is_emminting)
{
	global.particle_generators[?self.id] = part_system_create(par_runes);
	is_emminting = true;
	var _particle_emmiter = particle_get_info(global.particle_generators[?self.id]).emitters[0];
	part_emitter_region(global.particle_generators[?self.id], _particle_emmiter.ind, x, x + TILE_WIDTH, y, y + TILE_WIDTH, ps_shape_rectangle, ps_distr_linear);
}

if (energy < STONE_ENERGY_MAX and is_emminting)
{
	is_emminting = false;
	part_system_destroy(global.particle_generators[?self.id]);
	global.particle_generators[?self] = noone;
}
update_shadow(self);
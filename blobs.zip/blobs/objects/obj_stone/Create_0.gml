event_inherited();

function is_clicked()
{
	if (energy <= 0 && global.energy >= 1)
	{
		magic_sound()
		global.energy -= 1;
		energy += STONE_ENERGY_PER_SECOND/TICS_PER_SECOND;
	}
}

function is_right_clicked()
{

}

function has_energy()
{
	return energy >= STONE_ENERGY_MAX;
}

function collect_all()
{
	global.energy += energy;
	energy = 0;
}

is_emminting = false;

add_shadow(self);
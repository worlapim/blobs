
draw_self();
if (energy > 0)
{
	draw_sprite_ext(spr_runes,0,x ,y , image_xscale, image_yscale, 0,c_fuchsia,1/3 + energy/STONE_ENERGY_MAX*(2/3));
	surface_set_target(global.clock.night_surfice);
	gpu_set_blendmode(bm_subtract);
	draw_sprite_ext(spr_light_circle, 0, 
		(self.x-global.camera.x+CAM_WIDTH/global.camera.zoom/4), 
		(self.y-global.camera.y+CAM_HEIGTH/global.camera.zoom/4 + 10), 
		self.image_xscale, self.image_yscale, 0, c_fuchsia, energy/STONE_ENERGY_MAX);
	gpu_set_blendmode(bm_normal);
	surface_reset_target();
}
remove_shadow(self);
part_system_destroy(global.particle_generators[?self]);
global.particle_generators[?self] = noone;
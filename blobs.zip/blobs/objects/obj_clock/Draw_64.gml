

draw_set_colour(c_black);
draw_sprite(spr_clock,0,CAM_WIDTH - BORDER_WIDTH - TILE_WIDTH, BORDER_WIDTH);
var _clock_centre_x = CAM_WIDTH - BORDER_WIDTH - TILE_WIDTH + TILE_WIDTH/2;
var _clock_centre_y = BORDER_WIDTH + TILE_WIDTH/2;
var _offset_x = sin((sec_in_day_now/sec_per_day) * (pi*2));
var _offset_y = cos((sec_in_day_now/sec_per_day) * (pi*2));

draw_line(_clock_centre_x, _clock_centre_y, _clock_centre_x - (_offset_x*20), _clock_centre_y + (_offset_y*20))

draw_set_color(c_white)
draw_text(BORDER_WIDTH,BORDER_WIDTH,global.energy)

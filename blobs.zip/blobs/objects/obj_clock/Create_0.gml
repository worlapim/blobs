sec_per_day = 60;
sec_in_day_now = 0;
sec_in_evening = 5;
is_night_fuzzy = 0;
global.clock = self;
night_surfice = noone;
sec_in_day_now += (1/TICS_PER_SECOND);
if (sec_in_day_now > sec_per_day)
{
	sec_in_day_now = 0
}

var _sec_in_day_now_rotated = ((sec_in_day_now + sec_per_day*(3/4))%sec_per_day);
is_night_fuzzy = max(0, min(1, ((_sec_in_day_now_rotated - (max(0, _sec_in_day_now_rotated - sec_per_day/2)*2)) - (sec_per_day - 2*sec_in_evening)/4)/sec_in_evening))

draw_surface(night_surfice,global.camera.x-CAM_WIDTH/4/global.camera.zoom,global.camera.y-CAM_HEIGTH/4/global.camera.zoom)
surface_free(night_surfice)
enum DIRECTIONS {
	NONE,
	NORTH,
	EAST,
	SOUTH,
	WEST,
}

function random_neigboring_slot(_x, _y)
{
	var _dir = irandom(3)
	switch (_dir)
	{
	    case 0:
			return {
			    x : _x + TILE_WIDTH,
			    y : _y,
			};
	    case 1:
			return {
			    x : _x - TILE_WIDTH,
			    y : _y,
			};
	    case 2:
			return {
			    x : _x,
			    y : _y + TILE_WIDTH,
			};
	    case 3:
			return {
			    x : _x,
			    y : _y - TILE_WIDTH,
			};
	    default:
			return {
			    x : _x,
			    y : _y,
			};
	}
}

function instance_nearest_multiple_objects(_x,_y,_object_array)
{
	var _length = array_length(_object_array);
	var _best = noone;
	var _best_distance = 0;
	for(var _i = 0; _i < _length; ++_i) {
		var _current = instance_nearest(x,y,_object_array[_i]);
		if (_current != noone)
		{
			var _current_distance = point_distance(_current.x, _current.y, _x, _y);
			if(_best == noone or _current_distance < _best_distance)
			{
				_best = _current;
				_best_distance = _current_distance;
			}
		}
	}
	return _best;
}
#macro TILE_WIDTH 64
#macro TICS_PER_SECOND 60
#macro STONE_ENERGY_PER_SECOND 10
#macro STONE_ENERGY_MAX 60
#macro CAM_WIDTH 1365
#macro CAM_HEIGTH 767
#macro BORDER_WIDTH 10
#macro STATIC_OBJECTS [obj_bricks,obj_bush,obj_flowers,obj_stone,obj_waypoint,obj_wood]
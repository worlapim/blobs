function rock_sound(){
	var _i = irandom(2)
	switch (_i)
	{
		case 0:
			audio_play_sound(snd_rock1,1,false)
		case 1:
			audio_play_sound(snd_rock2,1,false)
	}
}

function bush_sound(){
	var _i = irandom(2)
	switch (_i)
	{
		case 0:
			audio_play_sound(snd_bush3,1,false)
		case 1:
			audio_play_sound(snd_bush4,1,false)
	}
}

function magic_sound(){
	audio_play_sound(snd_magic,1,false)
}

function plop_sound(){
	audio_play_sound(snd_plop,1,false)
}
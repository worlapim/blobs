//function draw_shadow(_x,_y)
//{
//	draw_sprite_ext(spr_shadow,0,_x + ((global.clock.sec_in_day_now + global.clock.sec_per_day*(1/4))%global.clock.sec_per_day) - global.clock.sec_per_day*(2/4),_y,1,1,0,c_white,(1 - global.clock.is_night_fuzzy)/4);
//}

function add_shadow(_object)
{
	_object.shadow = instance_create_layer(_object.x,_object.y,"Shadows",obj_shadow);
}

function remove_shadow(_object)
{
	if (_object.shadow != noone)
	{
		instance_destroy(_object.shadow);
		_object.shadow = noone;
	}
}

function update_shadow(_object)
{
	if (_object.shadow != noone)
	{
		_object.shadow.x = _object.x;
		_object.shadow.y = _object.y;
		_object.shadow.image_xscale = _object.image_xscale;
		_object.shadow.image_yscale = _object.image_yscale;
	}
}


//function add_runes(_object)
//{
//	_object.runes = instance_create_layer(_object.x,_object.y,"Lights",obj_runes);
//}

//function remove_runes(_object)
//{
//	if (_object.runes != noone)
//	{
//		instance_destroy(_object.runes);
//		_object.runes = noone;
//	}
//}

//function update_runes(_object)
//{
//	if (_object.runes != noone)
//	{
//		_object.runes.x = _object.x;
//		_object.runes.y = _object.y;
//		_object.runes.image_xscale = _object.image_xscale;
//		_object.runes.image_yscale = _object.image_yscale;
//		if (_object.energy > 0)
//		{
//			_object.runes.image_alpha =  1/3 + _object.energy/STONE_ENERGY_MAX/(2/3);
//		}
//		else
//		{
//			_object.runes.image_alpha =  0;
//		}
//	}
//}
global.energy = 10;
global.clock = noone;
global.camera = noone;
global.particle_generators = ds_map_create();
global.fullscreen = false;
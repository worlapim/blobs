enum FRUITS {
	NONE,
	BASIC_FRUIT,
	TREE_BASIC_FRUIT,
	POLLINATION_FRUIT,
}

enum BUSH_STAGES {
	SAPPLING,
	BUSH,
	TREE,
}

function fruit_to_saturation(_fruits){
	switch (_fruits)
	{
	    case FRUITS.BASIC_FRUIT:
	        return 4;
	    case FRUITS.TREE_BASIC_FRUIT:
	        return 40;
	    case FRUITS.POLLINATION_FRUIT:
	        return 10;
	    default:
	        return 0;
	}
}
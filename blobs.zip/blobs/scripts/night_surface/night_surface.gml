function create_night_surface(){
	var _surface = surface_create(CAM_WIDTH/global.camera.zoom/2+1,CAM_HEIGTH/global.camera.zoom/2+1);
	surface_set_target(_surface);
	draw_clear_alpha(c_black,0);
	draw_set_colour(c_black);
	draw_set_alpha(is_night_fuzzy/1.5);
	//draw_rectangle( 
	//	global.camera.x-CAM_WIDTH/2/global.camera.zoom, 
	//	global.camera.y-CAM_HEIGTH/2/global.camera.zoom, 
	//	global.camera.x+CAM_WIDTH/2/global.camera.zoom, 
	//	global.camera.y+CAM_HEIGTH/2/global.camera.zoom, false );
	draw_rectangle( 
		0, 
		0, 
		CAM_WIDTH/2/global.camera.zoom+1, 
		CAM_HEIGTH/2/global.camera.zoom+1, false );
	draw_set_alpha(1);
	surface_reset_target();
	return _surface;
}
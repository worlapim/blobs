enum DEMANDS {
	NONE,
	CHOP_DOWN,
	CONSTRUCT,
	POLLINATE,
	length
}

enum ITEMS {
	NONE,
	SAPLING,
}


function get_hat(_demand)
{
	switch (_demand) 
	{
		case DEMANDS.CHOP_DOWN:
			return spr_blob_mine_helmet;
		case DEMANDS.CONSTRUCT:
			return spr_blob_construction;
		case DEMANDS.POLLINATE:
			return spr_blob_flower_crown;
		default:
			return noone;
	}
}
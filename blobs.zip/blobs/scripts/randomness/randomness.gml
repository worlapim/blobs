function random_around(_center, _radius, _not_negative)
{
	_not_negative = is_undefined(_not_negative) ? false : _not_negative;
	if (_not_negative)
	{
		return max(0, _center + irandom(_radius*2) - _radius);
	}
	return _center + irandom(_radius*2) - _radius;
}